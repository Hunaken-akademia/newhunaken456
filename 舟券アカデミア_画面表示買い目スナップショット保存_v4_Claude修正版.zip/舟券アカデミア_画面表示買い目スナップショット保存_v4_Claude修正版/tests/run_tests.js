import fs from "fs";

const src = fs.readFileSync("/home/claude/claude_debug_package/src/App.jsx", "utf8");

// App.jsx内の実関数をそのまま抽出して評価する（コピペではなく実コードをテスト）
function extractFunction(name) {
  const start = src.indexOf(`function ${name}(`);
  if (start < 0) throw new Error(`function ${name} not found`);
  let i = src.indexOf("{", start);
  let depth = 0;
  for (; i < src.length; i++) {
    if (src[i] === "{") depth++;
    else if (src[i] === "}") { depth--; if (depth === 0) { i++; break; } }
  }
  return src.slice(start, i);
}

const fnNames = [
  "normalizeTrifectaResult",
  "expandTrifectaTicket",
  "ticketListIncludesResult",
  "expandTicketsForSave",
  "compressTickets",
];
const code = fnNames.map(extractFunction).join("\n\n")
  + `\nexport { ${fnNames.join(", ")} };`;
fs.writeFileSync("/home/claude/extracted_fns.mjs", code);
const {
  expandTrifectaTicket,
  ticketListIncludesResult,
  expandTicketsForSave,
  compressTickets,
} = await import("/home/claude/extracted_fns.mjs");

// 一括記録の保存部と同一のロジック（startBatchBetRecordingのレコード生成を再現）
function buildBatchTicketsFromSnapshot(snapshotBets, label, limit) {
  if (!limit) return [];
  const source = snapshotBets.find((b) => String(b?.label || "") === label);
  return expandTicketsForSave(Array.isArray(source?.tickets) ? source.tickets : []);
}

let pass = 0, fail = 0;
const check = (name, cond, detail = "") => {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name} ${detail}`); }
};
const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);

console.log("── テスト1：圧縮展開（result=3-1-5 / displayed=[3-1-245, 3-2-1]）");
{
  const displayed = ["3-1-245", "3-2-1"];
  const tickets = expandTicketsForSave(displayed);
  const expected = ["3-1-2", "3-1-4", "3-1-5", "3-2-1"];
  check("展開結果が期待通り", eq(tickets, expected), `got=${JSON.stringify(tickets)}`);
  check("的中判定 hit=true", ticketListIncludesResult(tickets, "3-1-5") === true);
  check("表示配列のままでも hit=true（内部で展開照合）", ticketListIncludesResult(displayed, "3-1-5") === true);
}

console.log("── テスト2：result=1-2-5 / displayed=[1-25-3, 1-3-25] → hit=false");
{
  const displayed = ["1-25-3", "1-3-25"];
  const tickets = expandTicketsForSave(displayed);
  // 展開: 1-2-3, 1-5-3, 1-3-2, 1-3-5 → 1-2-5 は含まれない
  check("展開に 1-2-5 が含まれない", !tickets.includes("1-2-5"), `got=${JSON.stringify(tickets)}`);
  check("的中判定 hit=false", ticketListIncludesResult(tickets, "1-2-5") === false);
  check("表示配列のままでも hit=false", ticketListIncludesResult(displayed, "1-2-5") === false);
}

console.log("── テスト3：result=4-1-2 / displayed=[4-1-2356] → hit=true");
{
  const displayed = ["4-1-2356"];
  const tickets = expandTicketsForSave(displayed);
  check("展開に 4-1-2 が含まれる", tickets.includes("4-1-2"), `got=${JSON.stringify(tickets)}`);
  check("的中判定 hit=true", ticketListIncludesResult(tickets, "4-1-2") === true);
}

console.log("── テスト4：保存一致（4Rの画面表示元配列 → 保存tickets）");
{
  // 画面表示: 対抗 3-1-245 / 3-2-1（表示元は展開済み配列。圧縮はcompressTicketsによる表示専用）
  const displaySource = ["3-1-2", "3-1-4", "3-1-5", "3-2-1"]; // aiEvalが持つ実配列（表示スライス後）
  const snapshotBets = [{ label: "対抗", tickets: expandTicketsForSave(displaySource) }];
  const saved = buildBatchTicketsFromSnapshot(snapshotBets, "対抗", 4);
  const expected = ["3-1-2", "3-1-4", "3-1-5", "3-2-1"];
  check("保存ticketsが表示展開と完全一致", eq(saved, expected), `got=${JSON.stringify(saved)}`);
  check("結果 3-1-5 で対抗的中", ticketListIncludesResult(saved, "3-1-5") === true);
  // 表示の圧縮形が期待通りであること（画面 3-1-245 / 3-2-1 の再現）
  const compressed = compressTickets(displaySource);
  check("compressTicketsで 3-1-245 / 3-2-1 に戻る", eq([...compressed].sort(), ["3-1-245", "3-2-1"]), `got=${JSON.stringify(compressed)}`);
  // 圧縮形がスナップショットに紛れ込んでも保存時に必ず展開される（要件C）
  const savedFromCompressed = buildBatchTicketsFromSnapshot([{ label: "対抗", tickets: ["3-1-245", "3-2-1"] }], "対抗", 4);
  check("圧縮形入力でも保存は完全展開", eq(savedFromCompressed, expected), `got=${JSON.stringify(savedFromCompressed)}`);
}

console.log("── 重複除去（要件C）");
{
  const t = expandTicketsForSave(["1-2-34", "1-2-3", "1-2-4"]);
  check("重複が除去される", eq(t, ["1-2-3", "1-2-4"]), `got=${JSON.stringify(t)}`);
}

console.log("── 実データ検証：旧v3保存（iframe再計算）と画面表示の不一致の再確認");
{
  const backup = JSON.parse(fs.readFileSync("/home/claude/claude_debug_package/evidence/hunaken-backup-2026-07-29.json", "utf8"));
  const taikou4R = backup.betRecords.find((b) => b.venue === "びわこ" && b.race === 4 && b.label === "対抗");
  console.log("  旧保存 4R対抗:", JSON.stringify(taikou4R.tickets));
  check("旧保存は結果3-1-5で不的中（バグの再現）", ticketListIncludesResult(taikou4R.tickets, "3-1-5") === false);
  const displayedExpanded = expandTicketsForSave(["3-1-245", "3-2-1"]);
  console.log("  画面表示の展開:", JSON.stringify(displayedExpanded));
  check("画面表示なら対抗的中だった", ticketListIncludesResult(displayedExpanded, "3-1-5") === true);
  check("旧保存と画面表示は不一致", !eq([...taikou4R.tickets].sort(), [...displayedExpanded].sort()));
}

console.log(`\n結果: ${pass} passed / ${fail} failed`);
process.exit(fail ? 1 : 0);
